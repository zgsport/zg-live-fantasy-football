# ZG Live — Fantasy Football TikTok question queue

One Node.js app provides three separate pages backed by the same database:

- Public question form: `/` (intended domain `ask.zg.live`)
- Private moderation dashboard: `/admin`
- Transparent browser overlay: `/overlay?key=YOUR_OVERLAY_KEY` (only needed if you set `OVERLAY_KEY`)

## Features
- Start/sit and trade question intake, TikTok username, optional league format.
- Admin password login; pending/accepted/rejected/answered filters; accept, reject, return to pending, and write an on-screen answer.
- Overlay polls the latest accepted/answered question and displays its answer when supplied.
- Rate limiting, basic security headers, SQLite database.

## Run locally
Requires Node.js 20+.

```bash
npm install
ADMIN_PASSWORD='use-a-long-unique-password' OVERLAY_KEY='some-random-secret' npm start
```
Open `http://localhost:3000`, `http://localhost:3000/admin`, and `http://localhost:3000/overlay?key=some-random-secret`.

## Deploy to Render
1. Push this folder to a Git repository you control.
2. In Render, create a Blueprint from that repository and use `render.yaml`.
3. Set `ADMIN_PASSWORD` to a strong unique password and `OVERLAY_KEY` to a long random value in the Render environment settings. Do not share the admin password.
4. The Blueprint configures a persistent disk mounted at `/var/data`; SQLite data lives there. The service uses a paid Starter plan because persistent disks require a paid web service.
5. After deploy, test `/health`, the public form, and `/admin`.

## Connect `ask.zg.live`
In Render, open the web service's **Settings → Custom Domains**, add `ask.zg.live`, and follow the exact DNS instructions Render gives you at your DNS provider. Wait for domain verification and TLS. The domain cannot be connected automatically from this code bundle; you must own/control its DNS and add the records Render specifies.

## TikTok Studio overlay
1. Open `/overlay?key=YOUR_OVERLAY_KEY` in a browser first and verify it works.
2. In TikTok LIVE Studio, add a **Browser/Webpage** source if available in your version, and paste that full overlay URL. Set the source to your desired size (e.g. 1080×1920 for portrait layout). If your TikTok Studio version lacks a browser source, use OBS browser source and the supported virtual-camera/stream workflow.
3. In the admin page, click **Accept** for a question to display it. Type your response and click **Publish answer** to mark it answered and show your answer on screen. The latest accepted/answered question stays on overlay until a newer one is accepted/answered.

## Important security/operations notes
- This is a working starter implementation, not a deployment already live at `ask.zg.live`. No domain or hosting account was modified by generating these files.
- Configure the admin password before launch. The overlay key is optional but recommended if you do not want arbitrary visitors querying the overlay endpoint.
- Use one Render instance with this SQLite setup. If you later scale to multiple instances, migrate the database to PostgreSQL.
- Admin login sessions are held in server memory and expire when the service restarts; sign in again after a restart.
